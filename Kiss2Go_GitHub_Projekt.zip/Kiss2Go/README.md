# Kiss2Go

Minimaler Android-Build für GitHub Actions zur Erstellung eines Debug-APKs.