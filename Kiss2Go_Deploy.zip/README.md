# Kiss2Go
Minimaler Android-Build für GitHub Actions.
